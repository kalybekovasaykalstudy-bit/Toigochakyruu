const openButton = document.getElementById("openInvitation");
const envelopeScreen = document.getElementById("envelopeScreen");
const invitation = document.getElementById("invitation");
const song = document.getElementById("weddingSong");
const musicControl = document.getElementById("musicControl");
const musicLabel = document.getElementById("musicLabel");

let isPlaying = false;

openButton.addEventListener("click", async () => {
  if (openButton.classList.contains("opened")) return;

  openButton.classList.add("opened");

  // Музыка браузердин эрежелерине ылайык конок баскандан кийин гана башталат.
  try {
    await song.play();
    isPlaying = true;
    updateMusicButton();
  } catch (error) {
    // Эгер браузер аудиону баштоого уруксат бербесе, конок музыка баскычын колдоно алат.
    isPlaying = false;
    updateMusicButton();
  }

  window.setTimeout(() => {
    envelopeScreen.classList.add("leaving");
    envelopeScreen.style.opacity = "0";
    envelopeScreen.style.transform = "translateY(-18px)";
    window.setTimeout(() => {
      envelopeScreen.hidden = true;
      invitation.classList.remove("hidden");
      invitation.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 650);
  }, 1050);
});

musicControl.addEventListener("click", async () => {
  if (isPlaying) {
    song.pause();
    isPlaying = false;
  } else {
    try {
      await song.play();
      isPlaying = true;
    } catch (error) {
      musicLabel.textContent = "Музыканы кайра басыңыз";
      return;
    }
  }
  updateMusicButton();
});

song.addEventListener("ended", () => {
  // Аудио файл loop менен коюлган; бул кошумча абал синхрондоштуруусу.
  isPlaying = false;
  updateMusicButton();
});

function updateMusicButton() {
  musicControl.classList.toggle("paused", !isPlaying);
  musicControl.setAttribute("aria-label", isPlaying ? "Музыканы токтотуу" : "Музыканы ойнотуу");
  musicLabel.textContent = isPlaying ? "Музыка ойноодо" : "Музыканы угуу";
}
